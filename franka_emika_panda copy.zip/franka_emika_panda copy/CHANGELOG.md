# Changelog – Franka Emika Panda Description

All notable changes to this model will be documented in this file.

## [2025-07-02]
- Explicitly exclude contacts between the base and the first link.

## [2022-09-07]
- Initial release.
